define(function() {
    Q.module('DisplayObject');
});

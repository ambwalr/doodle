define(function() {
    Q.module('Point');
});

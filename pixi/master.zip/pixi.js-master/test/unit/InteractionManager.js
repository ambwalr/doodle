define(function() {
    Q.module('InteractionManager');
});

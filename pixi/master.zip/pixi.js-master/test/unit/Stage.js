define(function() {
    Q.module('Stage');
});

define(function() {
    Q.module('MovieClip');
});

define(function() {
    Q.module('AssetLoader');
});

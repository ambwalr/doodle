define(function() {
    Q.module('EventTarget');
});

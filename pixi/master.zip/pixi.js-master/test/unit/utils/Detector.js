define(function() {
    Q.module('Detector');
});

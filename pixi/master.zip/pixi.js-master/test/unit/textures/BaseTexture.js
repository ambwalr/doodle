define(function() {
    Q.module('BaseTexture');
});

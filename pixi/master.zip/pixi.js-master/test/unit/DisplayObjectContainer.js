define(function() {
    Q.module('DisplayObjectContainer');
});
